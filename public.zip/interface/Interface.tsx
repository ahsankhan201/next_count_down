export interface DATE {
  date: Date | any;
}
export interface links {
  facebooklink?: string;
  twitterlink?: string;
}
