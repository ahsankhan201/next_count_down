import type { NextPage } from "next";
import { useState } from "react";
import styles from "../styles/Home.module.css";
import CountDown from "../count_down/CountDown";
import { DATE, links } from "../../interface/Interface";
import Model from "../model/Model";

const MainCountDown: NextPage = () => {
  const [target, setTarget] = useState(new Date("05/24/2022 22:59:59"));
  const linkss = {
    facebooklink: "weewwe",
    twitterlink: "adssd",
  };
  const [links, setLinks] = useState({
    facebooklink: "https://www.w3schools.com/",
    twitterlink: "adssd",
  });

  return (
    <div>
      <CountDown data={target} />
      {/* <Model links={links} /> */}
    </div>
  );
};

export default MainCountDown;
