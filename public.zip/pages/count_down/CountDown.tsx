import type { NextPage } from "next";
import { useEffect, useState } from "react";
import styles from "../../styles/Home.module.css";

interface Props {
  data: Date;
}
const CountDown: React.FC<Props> = (props: Props) => {
  const [days, setDays] = useState(0);
  const [hours, setHours] = useState(0);
  const [minutes, setMinutes] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [open, setOpen] = useState(false);
  const [target, setTarget] = useState<Date>(new Date("05/24/2022 22:59:59"));

  const openModel = () => {
    setOpen(true);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const difference = target.getTime() - now.getTime();
      const d = Math.floor(difference / (1000 * 60 * 60 * 24));
      setDays(d);
      const h = Math.floor(
        (difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
      );

      setHours(h);

      const m = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      setMinutes(m);

      const s = Math.floor((difference % (1000 * 60)) / 1000);
      setSeconds(s);
      if (difference <= 0) {
        clearInterval(interval);

        setDays(0);
        setHours(0);
        setMinutes(0);
        setSeconds(0);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [target]);
  return (
    <div className={styles.container}>
      <>
        <div className={styles.countWrapper}>
          <h3>Moon Landing Party</h3>
          <h1>07.16.22</h1>
          <h4>Anniversary Starts in:</h4>
          <div className={styles.main}>
            <div className={styles.countItem}>
              <div className={styles.countValue}>{days}</div>
              <div className={styles.countUnit}>days</div>
            </div>
            <div className={styles.countItem}>
              <div className={styles.countValue}>{hours}</div>
              <div className={styles.countUnit}>hours</div>
            </div>
            <div className={styles.countItem}>
              <div className={styles.countValue}>{minutes}</div>
              <div className={styles.countUnit}>minutes</div>
            </div>

            <div className={styles.countItem}>
              <div className={styles.countValue}>{seconds}</div>
              <div className={styles.countUnit}>Seconds</div>
            </div>
          </div>
          <div>
            <button className={styles.shareBtn} onClick={openModel}>
              Share Event
            </button>
          </div>
        </div>
      </>
    </div>
  );
};

export default CountDown;

{
  /* <div className="timer-inner">
  <div className="timer-segment">
    <span className="time">{days}</span>
    <span className="label">Days</span>
  </div>
  <span className="divider">:</span>
  <div className="timer-segment">
    <span className="time">{hours}</span>
    <span className="label">Hours</span>
  </div>
  <span className="divider">:</span>
  <div className="timer-segment">
    <span className="time">{minutes}</span>
    <span className="label">Minutes</span>
  </div>
  <span className="divider">:</span>
  <div className="timer-segment">
    <span className="time">{seconds}</span>
    <span className="label">Seconds</span>
  </div>
</div>; */
}
